package com.driver;

import java.io.BufferedReader;
import java.io.InputStreamReader;

import com.dbconnections.DbOperations;
import com.domain.Employee;


public class Inputs 
{
	DbOperations db = new DbOperations();
	Employee emp = new Employee();
	
	static InputStreamReader ir=new InputStreamReader(System.in);
	static BufferedReader br=new BufferedReader(ir);
	
	public Employee insertEmp() throws Exception
	{
		System.out.println("Please, Enter the Employee's NAME");
		emp.setEmployee_Name(br.readLine());
		System.out.println("Enter the Employee's Address");
		emp.setEmployee_Address(br.readLine());
		System.out.println("Enter Employee's Date_of_joining(YYYY-MM-DD)");
		emp.setDate_Of_Joining(br.readLine());
		System.out.println("Enter Employee's Experience");
		String p=br.readLine(); 
		int exp = Integer.parseInt(p);
		emp.setExperience(exp);
		System.out.println("Enter Employee's Date_of_Birth(YYYY-MM-DD)");
		emp.setDate_Of_Birth(br.readLine());

		int value = db.createEmployee(emp);
		if (value == 0)
			System.out.println("Employee not Created");
		else
			System.out.println("Employee Created");
		return emp;
		
	}
	
	void readEmp() throws Exception
	{
		System.out.println("Enter EmployeeId");
		String p=br.readLine(); 
		int id = Integer.parseInt(p);
		emp.setEmployee_Id(id);
		db.readEmployee(emp);
	}
	
	
	void updateEmp() throws Exception
	{
		System.out.println("Enter EmployeeId to update the details");
		String p=br.readLine(); 
		int id = Integer.parseInt(p);
		emp.setEmployee_Id(id);
		System.out.println("Enter EmployeeName");
		emp.setEmployee_Name(br.readLine());
		System.out.println("Enter EmployeeAddress");
		emp.setEmployee_Address(br.readLine());
		System.out.println("Enter Date_of_joining");
		emp.setDate_Of_Joining(br.readLine());
		System.out.println("Enter the Experience");
		String p1=br.readLine(); 
		int exp = Integer.parseInt(p1);
		emp.setExperience(exp);
		System.out.println("Enter Date_of_Birth");
		emp.setDate_Of_Birth(br.readLine());
		int value = db.updateEmployee(emp);
		if (value == 0)
			System.out.println("Employee details not Updated");
		else
			System.out.println("Employee details Updated");
	}
	
	void deleteEmp() throws Exception
	{
		System.out.println("Enter EmployeeId whose details to be removed");
		String p=br.readLine(); 
		int id = Integer.parseInt(p);
		emp.setEmployee_Id(id);

		int value = db.deleteEmployee(emp);
		if (value == 0)
			System.out.println("Employee not Deleted");
		else
			System.out.println("Employee Deleted");
	}
	}

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

