package com.domain;

public class Employee {
	private int employee_Id;
	private int experience;
	private String employee_Name;
	private String employee_Address;
	private String date_Of_Joining;
	private String date_Of_Birth;

	// constructor using all the fields
	public Employee(int employee_Id, int experience, String employee_Name, String employee_Address,
			String date_Of_Joining, String date_Of_Birth) {
		super();
		this.employee_Id = employee_Id;
		this.experience = experience;
		this.employee_Name = employee_Name;
		this.employee_Address = employee_Address;
		this.date_Of_Joining = date_Of_Joining;
		this.date_Of_Birth = date_Of_Birth;
	}

	public Employee( String employee_Name, String employee_Address, String date_Of_Joining,int experience,
			String date_Of_Birth) {
		super();
		this.experience = experience;
		this.employee_Name = employee_Name;
		this.employee_Address = employee_Address;
		this.date_Of_Joining = date_Of_Joining;
		this.date_Of_Birth = date_Of_Birth;
	}

	// zero parameterized constructor
	public Employee() {
		super();
	}

	public int getEmployee_Id() {
		return employee_Id;
	}

	public void setEmployee_Id(int employee_Id) {
		this.employee_Id = employee_Id;
	}

	public int getExperience() {
		return experience;
	}

	public void setExperience(int experience) {
		this.experience = experience;
	}

	public String getEmployee_Name() {
		return employee_Name;
	}

	public void setEmployee_Name(String employee_Name) {
		this.employee_Name = employee_Name;
	}

	public String getEmployee_Address() {
		return employee_Address;
	}

	public void setEmployee_Address(String employee_Address) {
		this.employee_Address = employee_Address;
	}

	public String getDate_Of_Joining() {
		return date_Of_Joining;
	}

	public void setDate_Of_Joining(String date_Of_Joining) {
		this.date_Of_Joining = date_Of_Joining;
	}

	public String getDate_Of_Birth() {
		return date_Of_Birth;
	}

	public void setDate_Of_Birth(String date_Of_Birth) {
		this.date_Of_Birth = date_Of_Birth;
	}



}
