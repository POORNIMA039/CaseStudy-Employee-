package com.dbconnections;

public class SqlQueries {


	//Sql queries to insert, update,display and Delete
	public static final String query1 = "INSERT INTO tb_employee"
			+ "(employee_Name,employee_Address,date_Of_Joining,experience,date_Of_Birth) values \r\n"
			+ "(?,?,?,?,?)";
	public static final String query2 = "SELECT * FROM tb_employee WHERE employee_Id=";
	public static final String query3 = "UPDATE tb_employee SET employee_Name=?,employee_Address=?,date_Of_Joining=?,experience=?,date_Of_Birth=? WHERE employee_Id=?";
	public static final String query4 = "DELETE FROM tb_employee WHERE employee_Id=?";
	
}
