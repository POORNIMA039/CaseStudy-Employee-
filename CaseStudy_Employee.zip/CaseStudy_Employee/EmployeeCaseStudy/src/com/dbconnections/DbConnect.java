package com.dbconnections;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DbConnect {
	static String url = "jdbc:mysql://localhost:3306/db_employee";
	static String user = "root";
	static String pass = "root";
	public static Connection con = null;
	public static Statement stmt = null;
	public static PreparedStatement pstmt;
	public static ResultSet rs;

	// Establishes Connection with Sql Server
	public static Connection openConnection() throws SQLException {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection(url, user, pass);
			if (con != null) {
				System.out.println(" Susccefully Connected to database");
			}
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Failed in loading a driver or getting connection,please try once again");
			cnfe.printStackTrace();
		}
		return con;
	}

	// close connection
	public static void closeConnection() {
		try {
			if (stmt != null)
				stmt.close();
			if (con != null)
				con.close();
		} catch (Exception e) {
			System.out.println(e.toString());
		}
	}
}
