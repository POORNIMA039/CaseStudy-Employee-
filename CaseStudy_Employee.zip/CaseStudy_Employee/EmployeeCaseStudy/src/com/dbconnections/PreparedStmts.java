package com.dbconnections;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import com.domain.Employee;

public class PreparedStmts {
	// accepts connection object, SQL Query,and user Object as a parameter.and
	// sets to values & returns PreparedStatement object.
	static PreparedStatement pstmt;

	public static PreparedStatement insert(Connection con, String s, Employee emp) {
		try {
			pstmt = con.prepareStatement(s, Statement.RETURN_GENERATED_KEYS);
			pstmt.setString(1, emp.getEmployee_Name());
			pstmt.setString(2, emp.getEmployee_Address());
			pstmt.setString(3, emp.getDate_Of_Joining());
			pstmt.setInt(4, emp.getExperience());
			pstmt.setString(5, emp.getDate_Of_Birth());

		} catch (SQLException e) {
			System.out.println("Error!!");
			e.printStackTrace();
		}
		return pstmt;
	}

	public static PreparedStatement update(Connection con, String up, Employee emp) {
		try {
			pstmt = con.prepareStatement(up);
			pstmt = con.prepareStatement(SqlQueries.query3);
			pstmt.setInt(6, emp.getEmployee_Id());
			pstmt.setString(1, emp.getEmployee_Name());
			pstmt.setString(2, emp.getEmployee_Address());
			pstmt.setString(3, emp.getDate_Of_Joining());
			pstmt.setInt(4, emp.getExperience());
			pstmt.setString(5, emp.getDate_Of_Birth());
		} catch (SQLException e) {
			System.out.println("Error!!");
			e.printStackTrace();
		}
		return pstmt;
	}

	public static PreparedStatement delete(Connection con, String del, Employee emp) {
		try {
			pstmt = con.prepareStatement(del);
			pstmt.setInt(1, emp.getEmployee_Id());
		} catch (SQLException e) {
			System.out.println("Error!!");
			e.printStackTrace();
		}
		return pstmt;
	}

}
