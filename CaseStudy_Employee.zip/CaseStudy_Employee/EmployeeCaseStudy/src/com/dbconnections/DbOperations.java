package com.dbconnections;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import com.domain.Employee;

public class DbOperations {
	private static int r = 0;

	// Creating a Employee details
	public int createEmployee(Employee ep) throws Exception {
		Connection con = null;
		PreparedStatement pstmt = null;
		int res = 0;
		try {
			con = DbConnect.openConnection();
			String input = SqlQueries.query1; // fetching sql query from SqlQueries Class.
			pstmt = PreparedStmts.insert(con, input, ep);
			res = pstmt.executeUpdate();
			ResultSet rs = pstmt.getGeneratedKeys();
			displayKey(rs); // method to display a value using Resultset
		} catch (SQLException se) {
			se.printStackTrace();
		} finally {
			DbConnect.closeConnection();
		}
		return res;
	}

	// Reading a details from employee table
	public void readEmployee(Employee ep1) throws Exception {
		try {
			Connection con = null;
			ResultSet rs = null;
			Statement stmt = null;
			con = DbConnect.openConnection();
			stmt = con.createStatement();
			rs = stmt.executeQuery(SqlQueries.query2 + ep1.getEmployee_Id());
			if (rs.first()) {
				rs = stmt.executeQuery(SqlQueries.query2 + ep1.getEmployee_Id());

				while (rs.next()) {

					System.out.println("employee_Id : " + rs.getInt("employee_Id") + "\nemployee_Name : "
							+ rs.getString("employee_Name") + "\nemployee_Address : " + rs.getString("employee_Address")
							+ "\ndate_of_Joining : " + rs.getString("date_Of_Joining") + "\nexperience : "
							+ rs.getInt("experience") + "\ndate_of_Birth : " + rs.getString("date_Of_Birth"));
				}
			} else {
				System.out.println("Employee with given Id not found");
			}
		} finally {
			DbConnect.closeConnection();
		}
	}

	// Update Employee Details
	public int updateEmployee(Employee ep2) throws Exception {
		Connection con = null;
		PreparedStatement pstmt = null;
		try {
			con = DbConnect.openConnection();
			String up = SqlQueries.query3; // fetching sql query from
											// SqlQueriesClass.
			pstmt = PreparedStmts.update(con, up, ep2); // calls PreparedStmts
														// to access prepared
														// statements and set
														// Values
			r = pstmt.executeUpdate();
		} catch (SQLException se) {
			se.printStackTrace();
		} finally {
			DbConnect.closeConnection();
		}
		return r;
	}

	// Deleting a employee's detail from the table employee
	public int deleteEmployee(Employee ep3) throws Exception {
		Connection con = null;
		PreparedStatement pstmt = null;
		try { // assigning connection class method to con establish connection with database
			con = DbConnect.openConnection(); // fetching sql query from
												// SqlQueries Class.
			pstmt = PreparedStmts.delete(con, SqlQueries.query4, ep3); // calls
																		// PreparedStmts
																		// to
																		// access
																		// preparedstatements
																		// and
																		// set
																		// Values
			r = pstmt.executeUpdate();
		} catch (SQLException se) {
			se.printStackTrace();
		}

		finally {
			DbConnect.closeConnection();
		}

		return r;
	}

	// Displaying Generated key value on successful Insertion of data into database
	private static void displayKey(ResultSet rs) {
		try {
			if (rs != null && rs.next()) {
				System.out.println();
				System.out.println();
				System.out.println("Congrats!! your Generated Employee_Id: " + rs.getInt(1));
				System.out.println("**************************************");
			} else
				System.out.println("There was an Error while Insertion ");
		} catch (SQLException e) {
			System.out.println(" ResultSet Error!!");
		}
	}
}
	