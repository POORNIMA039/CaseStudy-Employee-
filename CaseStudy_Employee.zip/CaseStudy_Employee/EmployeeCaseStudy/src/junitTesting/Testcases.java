package junitTesting;

import static org.junit.Assert.assertEquals;
import org.junit.Test;

import com.dbconnections.DbOperations;
import com.domain.Employee;

public class Testcases {

	/*
	 * Testing the Functionality with the Inputs given by the Users if the users
	 * provide right set of data the Test Will PASS Else the Test Will Fail
	 */
	@Test
	public void testCreateEmployee() throws Exception {

		DbOperations db = new DbOperations();
		Employee e1 = new Employee();
		e1.setEmployee_Name("pooja");
		e1.setEmployee_Address("delhi");
		e1.setDate_Of_Joining("2010-08-05");
		e1.setExperience(1);
		e1.setDate_Of_Birth("1999-11-21");

		int res = db.createEmployee(e1); // create and insert operation are same
		assertEquals(1, res);

	}

	@Test
	public void testUpdateEmployee() throws Exception {

		DbOperations db = new DbOperations();
		Employee e1 = new Employee();
		e1.setEmployee_Id(3);
		e1.setEmployee_Name("radha");
		e1.setEmployee_Address("bangalore");
		e1.setDate_Of_Joining("2017-08-05");
		e1.setExperience(1);
		e1.setDate_Of_Birth("1994-11-21");

		int res = db.updateEmployee(e1); // update operation
		assertEquals(1, res);

	}

	@Test
	public void testDeleteEmployee() throws Exception {

		DbOperations db = new DbOperations();
		Employee e1 = new Employee();
		e1.setEmployee_Id(7);

		int res = db.deleteEmployee(e1); // delete operation
		assertEquals(1, res);

	}
}


