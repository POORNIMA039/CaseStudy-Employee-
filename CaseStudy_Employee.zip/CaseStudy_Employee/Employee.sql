CREATE DATABASE db_employee;

USE db_employee;

SHOW TABLES;
DROP table tb_employee;
CREATE TABLE tb_employee (employee_Id integer AUTO_INCREMENT,
			employee_Name varchar(10) ,
			employee_Address varchar(20),
			date_Of_Joining date,
			experience integer,
			date_Of_Birth date,
			PRIMARY KEY(employee_Id));


insert into tb_employee(employee_Name, employee_Address, date_Of_Joining, experience, date_Of_Birth) values 
( 'poornima','Bengaluru','2019-07-04','1','1997-12-22');


SELECT * FROM tb_employee;